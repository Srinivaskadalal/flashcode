from pydantic import BaseModel, Field, HttpUrl
from datetime import datetime
from typing import Optional

# ✅ Event Schema
class EventModel(BaseModel):
    title: str = Field(..., min_length=3, max_length=100)
    description: str = Field(..., min_length=10)
    date: str = Field(..., regex=r"^\d{4}-\d{2}-\d{2}$")  # Format: YYYY-MM-DD
    time: str = Field(..., regex=r"^(0?[1-9]|1[0-2]):[0-5][0-9] (AM|PM)$")  # Format: HH:MM AM/PM
    location: str = Field(..., min_length=3, max_length=100)
    link: HttpUrl
    created_at: datetime = Field(default_factory=datetime.utcnow)

# ✅ Blog Schema
class BlogModel(BaseModel):
    title: str = Field(..., min_length=5, max_length=100)
    content: str = Field(..., min_length=20)
    author: str = Field(..., min_length=3, max_length=50)
    tags: list[str] = Field(default=[])
    created_at: datetime = Field(default_factory=datetime.utcnow)
