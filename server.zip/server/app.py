from flask import Flask
from flask_cors import CORS
from routes.events import bp as events_bp
from routes.blogs import bp as blogs_bp

app = Flask(__name__)

# Enable CORS (Cross-Origin Resource Sharing)
CORS(app, resources={r"/*": {"origins": "*"}})

# Register API Routes
app.register_blueprint(events_bp)
app.register_blueprint(blogs_bp)

if __name__ == "__main__":
    app.run(debug=True)
