from flask import Blueprint, request, jsonify
from datetime import datetime
from database import blogs_collection
from bson import ObjectId

bp = Blueprint("blogs", __name__, url_prefix="/blogs")

# ✅ Fetch All Blogs (Latest First)
@bp.route("/", methods=["GET"])
def get_all_blogs():
    try:
        blogs = list(blogs_collection.find({}, {"_id": 0}).sort("created_at", -1))
        return jsonify(blogs), 200
    except Exception as e:
        return jsonify({"error": f"Database error: {str(e)}"}), 500


# ✅ Fetch a Single Blog by ID
@bp.route("/<blog_id>", methods=["GET"])
def get_blog(blog_id):
    try:
        obj_id = ObjectId(blog_id)
        blog = blogs_collection.find_one({"_id": obj_id}, {"_id": 0})

        if not blog:
            return jsonify({"error": "Blog not found"}), 404

        return jsonify(blog), 200
    except:
        return jsonify({"error": "Invalid blog ID"}), 400


# ✅ Add a New Blog Post
@bp.route("/post", methods=["POST"])
def add_blog():
    data = request.json
    required_fields = ["title", "content", "author", "tags"]

    if not all(field in data for field in required_fields):
        return jsonify({"error": "Missing fields"}), 400

    # Validate Tags (should be a list)
    if not isinstance(data["tags"], list):
        return jsonify({"error": "Tags must be a list"}), 400

    # Add created_at timestamp
    data["created_at"] = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

    try:
        blogs_collection.insert_one(data)
        return jsonify({"message": "Blog added successfully!"}), 201
    except Exception as e:
        return jsonify({"error": f"Database error: {str(e)}"}), 500


# ✅ Update an Existing Blog Post
@bp.route("/update/<blog_id>", methods=["PUT"])
def update_blog(blog_id):
    data = request.json
    required_fields = ["title", "content", "author", "tags"]

    if not all(field in data for field in required_fields):
        return jsonify({"error": "Missing fields"}), 400

    # Validate Tags (should be a list)
    if not isinstance(data["tags"], list):
        return jsonify({"error": "Tags must be a list"}), 400

    try:
        obj_id = ObjectId(blog_id)
        result = blogs_collection.update_one({"_id": obj_id}, {"$set": data})

        if result.matched_count == 0:
            return jsonify({"error": "Blog not found"}), 404

        return jsonify({"message": "Blog updated successfully!"}), 200
    except:
        return jsonify({"error": "Invalid blog ID"}), 400


# ✅ Delete a Blog Post
@bp.route("/delete/<blog_id>", methods=["DELETE"])
def delete_blog(blog_id):
    try:
        obj_id = ObjectId(blog_id)
        result = blogs_collection.delete_one({"_id": obj_id})

        if result.deleted_count == 0:
            return jsonify({"error": "Blog not found"}), 404

        return jsonify({"message": "Blog deleted successfully!"}), 200
    except:
        return jsonify({"error": "Invalid blog ID"}), 400
